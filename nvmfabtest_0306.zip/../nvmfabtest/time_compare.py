import ctypes, subprocess, json, time

# Total
start = time.time()
for i in range(1):
    cmd = "pytest test_cases/nvme_fabric_cmds/connect_commands"
    # cmd = "pytest /root/nihal223/nvmfabtest/test_cases/nvme_fabric_cmds/"
    # cmd = cmd+"connect_commands/test_nvme_connect_006.py"
    # cmd = "pytest test_cases/test_sas.py"
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    stdout, stderr = process.communicate()
    # status = process.returncode

end = time.time()
print(end - start)