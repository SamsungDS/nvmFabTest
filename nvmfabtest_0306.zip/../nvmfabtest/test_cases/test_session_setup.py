def test_session_setup():
    assert True