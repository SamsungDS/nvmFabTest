
import ctypes, subprocess, json, time

start = time.time()
cmd = "pytest"
process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

stdout, stderr = process.communicate()
#status = process.returncode

end = time.time()
print(end - start)

# cmd = "nvme list-subsys -o json"
# process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

# stdout, stderr = process.communicate()
# status = process.returncode

# # print(stdout, end = '\n\n')
# js = json.loads(stdout)
# js = js[0]
# #print(js["Subsystems"],  end = '\n\n')

# connect_details = {
#         "transport": "tcp",
#         "addr": "10.0.0.220",
#         "svcid": "4420",
#         "index": 0
#     }

# tr = connect_details["transport"]
# addr = connect_details["addr"]
# svc = connect_details["svcid"]
# nqn = "nqn.2023-01.com.samsung.semiconductor:665e905a-bfde-11d3-01aa-a8a159fba2e6_0_0"

# def parse():
#     for subsystem in js["Subsystems"]:
#         # print(nqn == subsystem['NQN'].strip())
#         if nqn == subsystem['NQN'].strip():
            
#             if subsystem['Paths'][0]["Transport"] == tr:
                
#                 if subsystem['Paths'][0]["Address"] == f"traddr={addr},trsvcid={svc}":
#                     print("HERE")
#                     subsys_name = subsystem['Name'].strip()
#                     dev_path = f"/dev/nvme{subsys_name[-1]}"

#                     return(True, dev_path)
#     return(False, "NQN not found in the given response")

# print(parse())



# cmd = "/usr/sbin/nvme list-subsys -o json"
# process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

# stdout, stderr = process.communicate()
# status = process.returncode
# # print(stdout)
# js = json.loads(stdout)
# print(js["Subsystems"])




# class TEST3232(ctypes.Structure):
#     _fields_ = [("a", ctypes.c_uint32),
#                 ("b", ctypes.c_uint32),]

# class TEST64(ctypes.Structure):
#     _fields_ = [("a", ctypes.c_uint64),]


# def printbytes(structure: TEST3232):
#     bys = bytes(structure)
#     print(structure._fields_)
#     c=0
#     for b in bys:
#         print(c,":",format(b, '08b'))
#         c=c+1
# test32 = TEST3232()
# test64 = TEST64()
# test32.a
# i = test32.a

# print(i)

# print(r"0%----------100%")

# for i in range(0x103752168, 0xFFFFFFFFFFFFFFFF, 0x10):
#     test32.a = i
#     test32.b = i >> 32
#     #printbytes(test32)

#     test64.a = i
#     #printbytes(test64)
#     print(hex(i), bytes(test32)==bytes(test64))
#     if bytes(test32)!=bytes(test64):
#         print("False")
#         break 
# else:
#     print("True")
