""" For NVM Command Data Structures"""
import ctypes

