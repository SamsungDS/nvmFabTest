""" For NVM Command Structures"""
import ctypes
